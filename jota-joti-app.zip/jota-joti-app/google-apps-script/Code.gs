const CONFIG = {
  USERS_SHEET: 'Users',
  CATEGORIES_SHEET: 'Categories',
  LINKS_SHEET: 'Links',
  LOGOS_SHEET: 'Logos',
  BLOCKED_URLS_SHEET: 'BlockedURLs',
  BLOCKED_CATEGORIES_SHEET: 'BlockedCategories',
  SETTINGS_SHEET: 'Settings',

  BACKUP_FOLDER_NAME: 'JOTA-JOTI Backups',
  BACKUPS_TO_KEEP: 14,

  WEBSITE_URL: 'https://scoutpegs.github.io/jota-joti-app/',
  SCOUT_GROUP: 'Boulder Scout Group'
};

const CACHE_TTL_SECONDS = 45;
const CACHEABLE_SHEETS = [
  CONFIG.CATEGORIES_SHEET,
  CONFIG.LINKS_SHEET,
  CONFIG.LOGOS_SHEET,
  CONFIG.BLOCKED_URLS_SHEET,
  CONFIG.BLOCKED_CATEGORIES_SHEET,
  CONFIG.USERS_SHEET
];

/* ============================================================
   API ROUTER
   ============================================================ */

function doGet(e) {
  return handleRequest(e);
}

function doPost(e) {
  return handleRequest(e);
}

function handleRequest(e) {
  try {
    const action = e && e.parameter ? String(e.parameter.action || '').trim() : '';
    const pin = e && e.parameter ? e.parameter.pin || '' : '';

    if (action === 'health') {
      return jsonResponse({
        success: true,
        message: 'JOTA-JOTI API is running',
        organiser: CONFIG.SCOUT_GROUP,
        unofficial: true,
        serverTime: new Date().toISOString()
      });
    }

    if (action === 'diagnostics') {
      return jsonResponse(runDiagnostics());
    }

    if (action === 'login' || action === 'user') {
      if (String(pin).trim().toLowerCase() === 'guest') {
        return getUserDashboard('guest');
      }

      const result = loginUser(pin);
      if (!result.success) {
        return jsonResponse(result);
      }

      return getUserDashboard(pin);
    }

    if (action === 'categories') {
      return jsonResponse({ success: true, categories: getCachedSheetData(CONFIG.CATEGORIES_SHEET) });
    }

    if (action === 'links') {
      return jsonResponse({ success: true, links: getCachedSheetData(CONFIG.LINKS_SHEET) });
    }

    if (action === 'logos') {
      return jsonResponse({ success: true, logos: getCachedSheetData(CONFIG.LOGOS_SHEET) });
    }

    if (action === 'blocks') {
      return jsonResponse({
        success: true,
        blockedURLs: getCachedSheetData(CONFIG.BLOCKED_URLS_SHEET),
        blockedCategories: getCachedSheetData(CONFIG.BLOCKED_CATEGORIES_SHEET)
      });
    }

    if (action === 'all') {
      return getAllPublicData();
    }

    return jsonResponse({
      success: true,
      message: 'JOTA-JOTI API is running',
      organiser: CONFIG.SCOUT_GROUP,
      unofficial: true,
      endpoints: {
        health: '?action=health',
        diagnostics: '?action=diagnostics',
        login: '?action=login&pin=1234',
        user: '?action=user&pin=1234',
        categories: '?action=categories',
        links: '?action=links',
        logos: '?action=logos',
        blocks: '?action=blocks',
        all: '?action=all'
      }
    });

  } catch (error) {
    return jsonResponse({ success: false, error: error.message || String(error) });
  }
}

/* ============================================================
   DIAGNOSTICS
   ============================================================ */

function runDiagnostics() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const sheetNames = [
    CONFIG.USERS_SHEET, CONFIG.CATEGORIES_SHEET, CONFIG.LINKS_SHEET,
    CONFIG.LOGOS_SHEET, CONFIG.BLOCKED_URLS_SHEET, CONFIG.BLOCKED_CATEGORIES_SHEET,
    CONFIG.SETTINGS_SHEET
  ];

  const sheetReport = sheetNames.map(function(name) {
    const sheet = spreadsheet.getSheetByName(name);
    return { sheet: name, exists: !!sheet, rowCount: sheet ? Math.max(0, sheet.getLastRow() - 1) : 0 };
  });

  const triggers = ScriptApp.getProjectTriggers().map(function(trigger) {
    return { function: trigger.getHandlerFunction(), type: String(trigger.getEventType()) };
  });

  let samplePins = [];
  try {
    samplePins = getSheetData(CONFIG.USERS_SHEET).slice(0, 5).map(function(u) { return String(u.PIN || ''); });
  } catch (err) {
    samplePins = ['(could not read Users sheet: ' + err.message + ')'];
  }

  return {
    success: true,
    spreadsheetName: spreadsheet.getName(),
    spreadsheetId: spreadsheet.getId(),
    scriptTimeZone: Session.getScriptTimeZone(),
    serverTime: new Date().toISOString(),
    sheets: sheetReport,
    triggersInstalled: triggers,
    samplePinsInUsersSheet: samplePins
  };
}

/* ============================================================
   SPREADSHEET ADMIN MENU
   ============================================================ */

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('JOTA-JOTI Admin')
    .addItem('Run full setup (first time / after big changes)', 'setupEOISystem')
    .addSeparator()
    .addItem('Manage a scout\'s account', 'showAdminPanel')
    .addSeparator()
    .addItem('Create backup now', 'runManualBackup')
    .addItem('Check installed triggers', 'runManualTriggerCheck')
    .addItem('Clear cached data (force refresh)', 'runManualClearCache')
    .addSeparator()
    .addItem('Send me a test welcome email', 'testParentEmail')
    .addToUi();
}

function runManualBackup() {
  const name = backupSpreadsheetToDrive();
  SpreadsheetApp.getUi().alert('Backup created: ' + name + '\n\nFind it in your Drive, in a folder called "' + CONFIG.BACKUP_FOLDER_NAME + '".');
}

function runManualTriggerCheck() {
  const triggers = checkEOITrigger();
  if (triggers.length === 0) {
    SpreadsheetApp.getUi().alert('No triggers are installed. Run "Run full setup" from this menu first.');
    return;
  }
  const lines = triggers.map(function(t) { return '• ' + t.function + ' (' + t.type + ')'; });
  SpreadsheetApp.getUi().alert('Installed triggers:\n\n' + lines.join('\n'));
}

function runManualClearCache() {
  clearSheetCache();
  SpreadsheetApp.getUi().alert('Cache cleared. The dashboard and API will read fresh data on the next request.');
}

function showAdminPanel() {
  const html = HtmlService.createHtmlOutput(buildAdminPanelHtml())
    .setWidth(480)
    .setHeight(560);
  SpreadsheetApp.getUi().showModalDialog(html, 'Manage a scout\'s account');
}

/* ============================================================
   CACHING (keeps the dashboard fast for many people at once)
   ============================================================ */

function getCachedSheetData(sheetName) {
  const cache = CacheService.getScriptCache();
  const metaKey = 'sheet_' + sheetName + '_meta';
  const meta = cache.get(metaKey);

  if (meta !== null) {
    const chunkCount = parseInt(meta, 10) || 0;
    const keys = [];
    for (let i = 0; i < chunkCount; i++) keys.push('sheet_' + sheetName + '_' + i);
    const chunks = cache.getAll(keys);
    let json = '';
    let complete = true;
    for (let i = 0; i < chunkCount; i++) {
      const part = chunks['sheet_' + sheetName + '_' + i];
      if (part === undefined) { complete = false; break; }
      json += part;
    }
    if (complete) {
      try { return JSON.parse(json); } catch (e) { /* fall through to a fresh read */ }
    }
  }

  const data = getSheetData(sheetName);
  cacheSheetData(sheetName, data);
  return data;
}

function cacheSheetData(sheetName, data) {
  try {
    const json = JSON.stringify(data);
    const chunkSize = 90000;
    const chunks = [];
    for (let i = 0; i < json.length; i += chunkSize) chunks.push(json.slice(i, i + chunkSize));

    const payload = {};
    payload['sheet_' + sheetName + '_meta'] = String(chunks.length);
    chunks.forEach(function(chunk, i) { payload['sheet_' + sheetName + '_' + i] = chunk; });

    CacheService.getScriptCache().putAll(payload, CACHE_TTL_SECONDS);
  } catch (err) {
    // Caching is best-effort. A failure here should never break the API response.
  }
}

function clearSheetCache() {
  const cache = CacheService.getScriptCache();
  CACHEABLE_SHEETS.forEach(function(name) {
    const meta = cache.get('sheet_' + name + '_meta');
    if (meta === null) return;
    const count = parseInt(meta, 10) || 0;
    const keys = ['sheet_' + name + '_meta'];
    for (let i = 0; i < count; i++) keys.push('sheet_' + name + '_' + i);
    cache.removeAll(keys);
  });
}

/* ============================================================
   USER DASHBOARD & DATA RETRIEVAL
   ============================================================ */

function getUserDashboard(pin) {
  if (!pin) {
    return jsonResponse({ success: false, error: 'PIN is required' });
  }

  const categories = getCachedSheetData(CONFIG.CATEGORIES_SHEET);
  const links = getCachedSheetData(CONFIG.LINKS_SHEET);
  const logos = getCachedSheetData(CONFIG.LOGOS_SHEET);
  const blockedCategories = getCachedSheetData(CONFIG.BLOCKED_CATEGORIES_SHEET);

  let user;
  let allowedCategories = [];

  if (String(pin).trim().toLowerCase() === 'guest') {
    user = {
      PIN: 'guest', Name: 'Guest Scout', Username: 'GuestScout', Email: '',
      ParentEmail: '', AllowedCategories: '*', Status: 'Active', PaperworkStatus: 'Not Required'
    };
    allowedCategories = categories
      .map(function(category) { return String(category.CategoryKey || '').trim().toLowerCase(); })
      .filter(function(key) { return key !== ''; });
  } else {
    const users = getCachedSheetData(CONFIG.USERS_SHEET);

    user = users.find(function(row) {
      return String(row.PIN || '').trim().toLowerCase() === String(pin).trim().toLowerCase();
    });

    if (!user) {
      return jsonResponse({ success: false, error: 'PIN not found' });
    }

    const status = String(user.Status || '').trim().toLowerCase();
    if (status === 'disabled') {
      return jsonResponse({ success: false, error: 'This account has been disabled.' });
    }

    const rawCategories = String(user.AllowedCategories || '');
    if (rawCategories.trim() === '*' || !rawCategories.trim()) {
      allowedCategories = categories.map(function(category) {
        return String(category.CategoryKey || '').trim().toLowerCase();
      });
    } else {
      allowedCategories = rawCategories.split(',').map(function(item) {
        return String(item).trim().toLowerCase();
      }).filter(function(item) { return item !== ''; });
    }
  }

  const blockedCategoryKeys = [];
  blockedCategories.forEach(function(row) {
    if (parseBoolean(row.Active)) {
      const key = String(row.CategoryKey || '').trim().toLowerCase();
      if (key) blockedCategoryKeys.push(key);
    }
  });

  allowedCategories = allowedCategories.filter(function(key) {
    return blockedCategoryKeys.indexOf(key) === -1;
  });

  const logoMap = {};
  logos.forEach(function(logo) {
    const key = String(logo.LogoKey || '').trim();
    if (key) logoMap[key] = String(logo.LogoURL || '').trim();
  });

  const filteredCategories = categories
    .filter(function(category) {
      const key = String(category.CategoryKey || '').trim().toLowerCase();
      return allowedCategories.indexOf(key) !== -1;
    })
    .map(function(category) {
      const logoKey = String(category.LogoKey || '').trim();
      let logoURL = String(category.LogoURL || '').trim();
      if (logoKey && logoMap[logoKey]) logoURL = logoMap[logoKey];
      return {
        CategoryKey: category.CategoryKey || '', Title: category.Title || '',
        LogoKey: logoKey, LogoURL: logoURL, Description: category.Description || ''
      };
    });

  const filteredLinks = links
    .filter(function(link) {
      const categoryKey = String(link.CategoryKey || '').trim().toLowerCase();
      return allowedCategories.indexOf(categoryKey) !== -1;
    })
    .map(function(link) {
      const logoKey = String(link.LogoKey || '').trim();
      let logoURL = String(link.LogoURL || '').trim();
      if (logoKey && logoMap[logoKey]) logoURL = logoMap[logoKey];
      return {
        LinkID: link.LinkID || '', CategoryKey: link.CategoryKey || '', Title: link.Title || '',
        URL: link.URL || '', CanEmbed: parseBoolean(link.CanEmbed),
        RequiresLogin: parseAccessLevel(link.RequiresLogin),
        RequiresEmail: parseAccessLevel(link.RequiresEmail),
        ParentApproval: parseBoolean(link.ParentApproval), LeaderApproved: parseBoolean(link.LeaderApproved),
        Moderated: parseBoolean(link.Moderated), Active: parseBoolean(link.Active),
        LogoKey: logoKey, LogoURL: logoURL, BlockStatus: link.BlockStatus || '', Notes: link.Notes || ''
      };
    });

  const safeUser = {
    ParticipantID: user.ParticipantID || '', PIN: user.PIN || '', Name: user.Name || '',
    Username: user.Username || '', Email: resolveUserEmail(user), Password: String(user.Password || ''),
    AllowedCategories: user.AllowedCategories || '', Status: user.Status || '', PaperworkStatus: user.PaperworkStatus || ''
  };

  return jsonResponse({
    success: true, user: safeUser, categories: filteredCategories, links: filteredLinks,
    logos: logos, unofficial: true, organiser: CONFIG.SCOUT_GROUP
  });
}

/* ============================================================
   LOGIN VERIFICATION
   ============================================================ */

function loginUser(pin) {
  if (!pin) return { success: false, error: 'PIN required' };

  const users = getCachedSheetData(CONFIG.USERS_SHEET);
  const user = users.find(function(row) {
    return String(row.PIN || '').trim().toLowerCase() === String(pin).trim().toLowerCase();
  });

  if (!user) return { success: false, error: 'PIN not found' };

  const status = String(user.Status || '').trim().toLowerCase();
  if (status === 'disabled') return { success: false, error: 'This account has been disabled.' };

  return {
    success: true,
    user: {
      ParticipantID: user.ParticipantID || '', PIN: user.PIN || '', Name: user.Name || '',
      Username: user.Username || '', Email: resolveUserEmail(user),
      AllowedCategories: user.AllowedCategories || '', Status: user.Status || '', PaperworkStatus: user.PaperworkStatus || ''
    }
  };
}

/* ============================================================
   PUBLIC DATA & SHEET HELPERS
   ============================================================ */

function getAllPublicData() {
  return jsonResponse({
    success: true,
    categories: getCachedSheetData(CONFIG.CATEGORIES_SHEET),
    links: getCachedSheetData(CONFIG.LINKS_SHEET),
    logos: getCachedSheetData(CONFIG.LOGOS_SHEET),
    blockedURLs: getCachedSheetData(CONFIG.BLOCKED_URLS_SHEET),
    blockedCategories: getCachedSheetData(CONFIG.BLOCKED_CATEGORIES_SHEET)
  });
}

function getSheetData(sheetName) {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName(sheetName);

  if (!sheet) {
    const sheets = spreadsheet.getSheets();
    sheet = sheets.find(s => s.getName().toLowerCase() === sheetName.toLowerCase());
  }
  if (!sheet) throw new Error('Sheet not found: ' + sheetName);

  const values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) return [];

  const headers = values[0].map(header => String(header).trim());
  const rows = [];

  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    const item = {};
    for (let j = 0; j < headers.length; j++) item[headers[j]] = row[j];
    const hasData = row.some(val => String(val).trim() !== '');
    if (hasData) rows.push(item);
  }
  return rows;
}

function parseBoolean(value) {
  if (value === true || value === 1) return true;
  const text = String(value || '').trim().toLowerCase();
  return text === 'true' || text === 'yes' || text === '1' || text === 'active';
}

function parseAccessLevel(value) {
  const parsed = parseInt(value, 10);
  if (parsed === 1 || parsed === 3) return parsed;
  return 0;
}

function resolveUserEmail(user) {
  return String(user.Email || '').trim();
}

function jsonResponse(data) {
  return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}

/* ============================================================
   GOOGLE FORM SUBMISSION & AUTOMATED USER CREATION
   ============================================================ */

function onFormSubmit(e) {
  try {
    if (!e) throw new Error('No form event supplied.');

    const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    const usersSheet = spreadsheet.getSheetByName(CONFIG.USERS_SHEET);
    if (!usersSheet) throw new Error('The Users sheet does not exist.');

    const data = {};
    if (e.namedValues) {
      Object.keys(e.namedValues).forEach(function(key) {
        const val = e.namedValues[key];
        data[normaliseHeader(key)] = Array.isArray(val) ? String(val[0] || '').trim() : String(val || '').trim();
      });
    }

    if (e.range) {
      const sheet = e.range.getSheet();
      const rowNumber = e.range.getRow();
      const lastColumn = sheet.getLastColumn();
      const headers = sheet.getRange(1, 1, 1, lastColumn).getValues()[0];
      const row = sheet.getRange(rowNumber, 1, 1, lastColumn).getValues()[0];
      for (let i = 0; i < headers.length; i++) {
        const header = String(headers[i] || '').trim();
        if (header) data[normaliseHeader(header)] = String(row[i] || '').trim();
      }
    }

    const parentName = getFlexibleFormValue(data, ['Parent/Guardian Full Name', 'Parent Guardian Full Name', 'Parent Name', 'Guardian Name']);
    const parentEmail = getFlexibleFormValue(data, ['Parent/Guardian Email', 'Parent Guardian Email', 'Parent Email', 'Guardian Email', 'Email Address', 'Email']);
    const childFirstName = getFlexibleFormValue(data, ['Child First Name', 'Child first name', 'First Name', 'Child Name']);
    const childLastName = getFlexibleFormValue(data, ['Child Last Name', 'Child last name', 'Last Name']);
    const ageYear = getFlexibleFormValue(data, ["Child's age/year group", "Child's age/year group", 'Child Age', 'Age', 'Year Group', 'Age/Year Group']);
    const selectedActivities = getFlexibleFormValue(data, ['Which activities would your child like access to?', 'Activities', 'Activity']);
    const childEmail = getFlexibleFormValue(data, ["Child's Email", 'Child Email', 'Scout Email']);

    if (!parentEmail) throw new Error('Parent email address is missing.');
    if (!childFirstName) throw new Error('Child first name is missing.');

    const participantID = generateParticipantID();
    const pin = generateUniquePIN(usersSheet);
    const username = generateUniqueUsername(usersSheet, childFirstName);
    const password = generatePassword();
    const allowedCategories = convertActivitiesToCategories(selectedActivities);
    const now = new Date();

    addUserToSheet(usersSheet, {
      ParticipantID: participantID, PIN: pin, Name: (childFirstName + ' ' + childLastName).trim(),
      Username: username, Email: childEmail || '', AllowedCategories: allowedCategories,
      Password: password, ParentEmail: parentEmail, ParentName: parentName,
      ScoutGroup: CONFIG.SCOUT_GROUP, AgeYear: ageYear, Status: 'Pending',
      EOIReceived: now, AccountCreated: now, PaperworkStatus: 'Required',
      EmailStatus: 'Pending', Notes: 'Created automatically from Google Form Expression of Interest.'
    });

    SpreadsheetApp.flush();
    clearSheetCache();

    try {
      sendParentWelcomeEmail({
        parentName: parentName, parentEmail: parentEmail, childFirstName: childFirstName,
        childLastName: childLastName, ageYear: ageYear, participantID: participantID,
        username: username, pin: pin, password: password, allowedCategories: allowedCategories
      });
      updateUserEmailStatus(usersSheet, participantID, 'Sent');
    } catch (emailError) {
      updateUserEmailStatus(usersSheet, participantID, 'Failed: ' + emailError.message);
      throw emailError;
    }

    return true;
  } catch (error) {
    console.error('Form submission error:', error);
    notifyAdminOfError('onFormSubmit', error);
    throw error;
  }
}

function notifyAdminOfError(where, error) {
  try {
    const owner = Session.getEffectiveUser().getEmail();
    if (!owner) return;
    MailApp.sendEmail({
      to: owner,
      subject: 'JOTA-JOTI system error in ' + where,
      body: 'The JOTA-JOTI Apps Script hit an error in ' + where + ':\n\n' +
            (error && error.message ? error.message : String(error)) + '\n\n' +
            'Check the Apps Script execution log for the full details (Extensions > Apps Script > Executions).'
    });
  } catch (notifyError) {
    // Nothing more we can do here.
  }
}

/* ============================================================
   FORM PROCESSING UTILITIES
   ============================================================ */

function normaliseHeader(value) {
  return String(value || '')
    .replace(/\u2018/g, "'").replace(/\u2019/g, "'")
    .replace(/\u201C/g, '"').replace(/\u201D/g, '"')
    .replace(/\s+/g, ' ').trim().toLowerCase();
}

function getFlexibleFormValue(data, possibleNames) {
  for (let i = 0; i < possibleNames.length; i++) {
    const key = normaliseHeader(possibleNames[i]);
    if (Object.prototype.hasOwnProperty.call(data, key)) {
      const val = String(data[key] || '').trim();
      if (val) return val;
    }
  }
  const keys = Object.keys(data);
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    for (let j = 0; j < possibleNames.length; j++) {
      const wanted = normaliseHeader(possibleNames[j]);
      if (key === wanted || key.indexOf(wanted) !== -1 || wanted.indexOf(key) !== -1) {
        const val = String(data[key] || '').trim();
        if (val) return val;
      }
    }
  }
  return '';
}

function generateParticipantID() {
  const existing = getSheetData(CONFIG.USERS_SHEET);
  const year = new Date().getFullYear();
  let number = existing.length + 1;
  let id = 'JOTI-' + year + '-' + String(number).padStart(6, '0');
  while (existing.some(user => String(user.ParticipantID || '').trim() === id)) {
    number++;
    id = 'JOTI-' + year + '-' + String(number).padStart(6, '0');
  }
  return id;
}

function generateUniquePIN(usersSheet) {
  const users = getSheetData(CONFIG.USERS_SHEET);
  let attempts = 0;
  while (attempts < 1000) {
    const pin = String(Math.floor(1000 + Math.random() * 9000));
    const exists = users.some(user => String(user.PIN || '').trim() === pin);
    if (!exists) return pin;
    attempts++;
  }
  throw new Error('Could not generate a unique PIN.');
}

function generateUniqueUsername(usersSheet, firstName) {
  const users = getSheetData(CONFIG.USERS_SHEET);
  let cleanName = String(firstName || 'Scout').replace(/[^a-zA-Z0-9]/g, '');
  if (!cleanName) cleanName = 'Scout';

  for (let attempts = 0; attempts < 1000; attempts++) {
    const number = Math.floor(10 + Math.random() * 90);
    const username = cleanName + 'JOTA' + number;
    const exists = users.some(user => String(user.Username || '').trim().toLowerCase() === username.toLowerCase());
    if (!exists) return username;
  }
  throw new Error('Could not generate a unique username.');
}

function generatePassword() {
  const animals = ['Koala', 'Kangaroo', 'Wombat', 'Emu', 'Dingo', 'Wallaby', 'Eagle', 'Tiger', 'Lion', 'Panda', 'Penguin', 'Otter', 'Fox', 'Bear', 'Wolf', 'Rabbit', 'Dolphin', 'Turtle', 'Shark', 'Zebra'];
  const animal = animals[Math.floor(Math.random() * animals.length)];
  const number = Math.floor(10 + Math.random() * 90);
  return animal + '@' + number;
}

function convertActivitiesToCategories(activities) {
  const text = String(activities || '').toLowerCase();
  const categories = [];

  if (text.includes('chat') || text.includes('online')) categories.push('chat');
  if (text.includes('minecraft')) categories.push('minecraft');
  if (text.includes('game') || text.includes('puzzle')) categories.push('games');
  if (text.includes('geography') || text.includes('map') || text.includes('country')) categories.push('geography');
  if (text.includes('radio') || text.includes('communication') || text.includes('morse')) categories.push('radio');
  if (text.includes('scout')) categories.push('scouting');
  if (text.includes('activit')) categories.push('activities');
  if (text.includes('world') || text.includes('international')) categories.push('international');
  if (text.includes('resource') || text.includes('help')) categories.push('resources');

  return [...new Set(categories)].join(',');
}

function addUserToSheet(sheet, user) {
  const lastColumn = sheet.getLastColumn();
  if (lastColumn < 1) throw new Error('Users sheet has no columns.');
  const headers = sheet.getRange(1, 1, 1, lastColumn).getValues()[0];
  const row = [];

  headers.forEach(function(header) {
    const key = String(header || '').trim();
    row.push(Object.prototype.hasOwnProperty.call(user, key) ? user[key] : '');
  });

  sheet.appendRow(row);
}

function updateUserEmailStatus(sheet, participantID, status) {
  const data = sheet.getDataRange().getValues();
  if (data.length < 2) return;

  const headers = data[0].map(header => String(header || '').trim());
  const participantColumn = headers.indexOf('ParticipantID');
  const emailStatusColumn = headers.indexOf('EmailStatus');
  if (participantColumn === -1 || emailStatusColumn === -1) return;

  for (let i = 1; i < data.length; i++) {
    if (String(data[i][participantColumn]).trim() === String(participantID).trim()) {
      sheet.getRange(i + 1, emailStatusColumn + 1).setValue(status);
      return;
    }
  }
}

/* ============================================================
   ADMIN PANEL — edit a scout's account, resend emails, certificates
   ============================================================
   Opens from the "JOTA-JOTI Admin" menu in the spreadsheet. Search by
   PIN, Participant ID or name; edit the child's name/email inline;
   resend the parent's account-details email; or send a completion
   certificate once a scout has finished JOTA-JOTI.
   ============================================================ */

function buildAdminPanelHtml() {
  return `<!DOCTYPE html><html><head><base target="_top">
<style>
  body{font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#1a1a1a;margin:0;padding:16px;}
  h2{font-size:16px;margin:0 0 12px;}
  .row{display:flex;gap:8px;margin-bottom:12px;}
  input[type=text]{flex:1;padding:8px;border:1px solid #ccc;border-radius:6px;font-size:13px;}
  button{padding:8px 14px;border:none;border-radius:6px;background:#126a91;color:#fff;font-weight:bold;cursor:pointer;font-size:13px;}
  button.secondary{background:#eef2f5;color:#123b5d;}
  button:disabled{opacity:0.5;cursor:default;}
  .card{border:1px solid #e0e0e0;border-radius:8px;padding:14px;margin-top:10px;display:none;}
  label{display:block;font-weight:bold;margin:10px 0 4px;}
  .actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px;}
  .msg{margin-top:10px;padding:8px 10px;border-radius:6px;font-size:12px;display:none;}
  .msg.ok{background:#eef7ee;color:#1e5c1e;display:block;}
  .msg.err{background:#fdeaea;color:#8a1f1f;display:block;}
  .muted{color:#666;font-size:12px;}
</style></head><body>
  <h2>Manage a scout's account</h2>
  <div class="row">
    <input id="q" type="text" placeholder="Search by PIN, Participant ID or name">
    <button onclick="doSearch()">Search</button>
  </div>
  <div id="msg" class="msg"></div>
  <div id="card" class="card">
    <div class="muted" id="meta"></div>
    <label>Child's name</label>
    <input id="name" type="text">
    <label>Email</label>
    <input id="email" type="text">
    <div class="actions">
      <button onclick="doSave()">Save changes</button>
      <button class="secondary" onclick="doResend()">Resend account email to parent</button>
      <button class="secondary" onclick="doCertificate()">Send completion certificate</button>
    </div>
  </div>
<script>
  let currentId = null;

  function showMsg(text, ok){
    const m = document.getElementById('msg');
    m.textContent = text;
    m.className = 'msg ' + (ok ? 'ok' : 'err');
  }

  function doSearch(){
    const q = document.getElementById('q').value.trim();
    if (!q) return;
    document.getElementById('card').style.display = 'none';
    google.script.run.withSuccessHandler(onFound).withFailureHandler(onError).adminSearchUser(q);
  }

  function onFound(user){
    if (!user){ showMsg('No matching scout found.', false); return; }
    currentId = user.ParticipantID;
    document.getElementById('meta').textContent = 'PIN ' + user.PIN + ' · Parent: ' + (user.ParentName||'—') + ' (' + (user.ParentEmail||'no email on file') + ')';
    document.getElementById('name').value = user.Name || '';
    document.getElementById('email').value = user.Email || '';
    document.getElementById('card').style.display = 'block';
    showMsg('Loaded ' + user.Name + '.', true);
  }

  function doSave(){
    if (!currentId) return;
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    google.script.run.withSuccessHandler(function(){ showMsg('Saved.', true); }).withFailureHandler(onError)
      .adminUpdateUser(currentId, name, email);
  }

  function doResend(){
    if (!currentId) return;
    showMsg('Sending…', true);
    google.script.run.withSuccessHandler(function(){ showMsg('Account email resent to the parent.', true); }).withFailureHandler(onError)
      .adminResendWelcomeEmail(currentId);
  }

  function doCertificate(){
    if (!currentId) return;
    showMsg('Sending certificate…', true);
    google.script.run.withSuccessHandler(function(){ showMsg('Completion certificate emailed to the parent.', true); }).withFailureHandler(onError)
      .adminSendCertificate(currentId);
  }

  function onError(err){ showMsg(err && err.message ? err.message : String(err), false); }
</script>
</body></html>`;
}

function findUserRowIndex(sheet, query) {
  const values = sheet.getDataRange().getValues();
  const headers = values[0].map(h => String(h || '').trim());
  const col = name => headers.indexOf(name);
  const q = String(query || '').trim().toLowerCase();

  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    const pin = String(row[col('PIN')] || '').trim().toLowerCase();
    const id = String(row[col('ParticipantID')] || '').trim().toLowerCase();
    const name = String(row[col('Name')] || '').trim().toLowerCase();
    if (q && (pin === q || id === q || name.includes(q))) {
      return { rowIndex: i + 1, headers: headers };
    }
  }
  return null;
}

function rowToUserObject(sheet, rowIndex, headers) {
  const row = sheet.getRange(rowIndex, 1, 1, headers.length).getValues()[0];
  const obj = {};
  headers.forEach((h, i) => { obj[h] = row[i]; });
  return obj;
}

function adminSearchUser(query) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CONFIG.USERS_SHEET);
  if (!sheet) throw new Error('Users sheet not found.');
  const match = findUserRowIndex(sheet, query);
  if (!match) return null;
  return rowToUserObject(sheet, match.rowIndex, match.headers);
}

function adminUpdateUser(participantId, newName, newEmail) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CONFIG.USERS_SHEET);
  if (!sheet) throw new Error('Users sheet not found.');
  const match = findUserRowIndex(sheet, participantId);
  if (!match) throw new Error('Could not find that scout anymore.');

  const nameCol = match.headers.indexOf('Name');
  const emailCol = match.headers.indexOf('Email');
  if (nameCol > -1) sheet.getRange(match.rowIndex, nameCol + 1).setValue(newName);
  if (emailCol > -1) sheet.getRange(match.rowIndex, emailCol + 1).setValue(newEmail);

  SpreadsheetApp.flush();
  clearSheetCache();
  return true;
}

function adminResendWelcomeEmail(participantId) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CONFIG.USERS_SHEET);
  if (!sheet) throw new Error('Users sheet not found.');
  const match = findUserRowIndex(sheet, participantId);
  if (!match) throw new Error('Could not find that scout anymore.');

  const user = rowToUserObject(sheet, match.rowIndex, match.headers);
  if (!user.ParentEmail) throw new Error('This scout has no parent email on file.');

  const [childFirstName, ...rest] = String(user.Name || '').split(' ');
  sendParentWelcomeEmail({
    parentName: user.ParentName || 'Parent/Guardian',
    parentEmail: user.ParentEmail,
    childFirstName: childFirstName || user.Name || 'Scout',
    childLastName: rest.join(' '),
    ageYear: user.AgeYear || '',
    participantID: user.ParticipantID || '',
    username: user.Username || '',
    pin: user.PIN || '',
    password: user.Password || '',
    allowedCategories: user.AllowedCategories || ''
  });

  updateUserEmailStatus(sheet, participantId, 'Resent ' + new Date().toISOString());
  return true;
}

function adminSendCertificate(participantId) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(CONFIG.USERS_SHEET);
  if (!sheet) throw new Error('Users sheet not found.');
  const match = findUserRowIndex(sheet, participantId);
  if (!match) throw new Error('Could not find that scout anymore.');

  const user = rowToUserObject(sheet, match.rowIndex, match.headers);
  if (!user.ParentEmail) throw new Error('This scout has no parent email on file.');

  const pdfBlob = buildCertificatePdf(user.Name || 'Scout');
  sendCertificateEmail(user, pdfBlob);
  return true;
}

function buildCertificatePdf(scoutName) {
  const doc = DocumentApp.create('JOTA-JOTI Certificate — ' + scoutName + ' — temp');
  const body = doc.getBody();
  body.setPageWidth(842).setPageHeight(595); // landscape A4-ish

  body.appendParagraph('CERTIFICATE OF COMPLETION')
    .setHeading(DocumentApp.ParagraphHeading.TITLE)
    .setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  body.appendParagraph('JOTA-JOTI 2026').setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  body.appendParagraph(' ');
  body.appendParagraph('This certifies that').setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  const nameLine = body.appendParagraph(scoutName);
  nameLine.setHeading(DocumentApp.ParagraphHeading.HEADING1).setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  body.appendParagraph('has successfully taken part in Jamboree on the Air / Jamboree on the Internet, ' + CONFIG.SCOUT_GROUP + '.')
    .setAlignment(DocumentApp.HorizontalAlignment.CENTER);
  body.appendParagraph(' ');
  body.appendParagraph('Issued: ' + Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Etc/UTC', 'd MMMM yyyy'))
    .setAlignment(DocumentApp.HorizontalAlignment.CENTER);

  doc.saveAndClose();

  const file = DriveApp.getFileById(doc.getId());
  const pdfBlob = file.getAs(MimeType.PDF).setName('JOTA-JOTI Certificate - ' + scoutName + '.pdf');
  file.setTrashed(true);
  return pdfBlob;
}

function sendCertificateEmail(user, pdfBlob) {
  const subject = 'JOTA-JOTI 2026 — Certificate of completion for ' + (user.Name || 'your scout');
  const body =
    'Hello ' + (user.ParentName || 'Parent/Guardian') + ',\n\n' +
    (user.Name || 'Your scout') + ' has completed JOTA-JOTI 2026 with ' + CONFIG.SCOUT_GROUP + '.\n\n' +
    'Their certificate of completion is attached.\n\n' +
    'Thank you for taking part.\n\n' + CONFIG.SCOUT_GROUP;

  MailApp.sendEmail({ to: user.ParentEmail, subject: subject, body: body, attachments: [pdfBlob] });
}

/* ============================================================
   EMAIL NOTIFICATIONS
   ============================================================ */

function sendParentWelcomeEmail(account) {
  const subject = "JOTA-JOTI – " + account.childFirstName + "'s account details";
  const websiteURL = CONFIG.WEBSITE_URL;
  const logoURL = 'https://media.ffycdn.net/eu/world-organization-of-the-scout-movement/oZCw81N2JF9orwf3ff2M.png?mod=v1/resize=2400';

  const htmlBody = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body { margin: 0; padding: 0; background: #eef2f5; font-family: Arial, Helvetica, sans-serif; color: #263238; }
.email { width: 100%; padding: 35px 12px; box-sizing: border-box; }
.container { max-width: 680px; margin: 0 auto; background: #ffffff; border-radius: 18px; overflow: hidden; box-shadow: 0 8px 30px rgba(0,0,0,0.10); }
.brand { background: linear-gradient(135deg, #073b5c, #126a91); padding: 32px 25px 28px; text-align: center; }
.brand:after { content: ""; display: block; width: 70px; height: 4px; background: #f5c542; border-radius: 5px; margin: 22px auto 0; }
.logo { display: block; width: 310px; max-width: 90%; height: auto; margin: 0 auto; }
.brand-title { color: #ffffff; font-size: 14px; letter-spacing: 1.5px; margin-top: 18px; font-weight: bold; text-transform: uppercase; }
.content { padding: 35px 42px; }
h2 { margin: 0 0 20px; font-size: 22px; color: #123b5d; }
h3 { margin-top: 28px; margin-bottom: 15px; font-size: 18px; color: #123b5d; }
p { font-size: 15px; line-height: 1.7; }
.warning { margin: 24px 0; padding: 18px 20px; background: #fff8e5; border: 1px solid #f1d58a; border-radius: 9px; font-size: 15px; line-height: 1.7; }
.warning strong:first-child { color: #795900; }
.login-box { margin: 20px 0 25px; padding: 18px 20px; background: #eef7ee; border: 1px solid #c7e3c7; border-radius: 9px; box-sizing: border-box; }
.login-row { padding: 10px 0 13px; border-bottom: 1px solid #d6dfd6; font-size: 15px; line-height: 1.5; }
.login-row:last-child { border-bottom: none; padding-bottom: 2px; }
.label { color: #263238; font-size: 13px; font-weight: bold; }
.value { font-family: monospace; font-size: 17px; }
.button { display: inline-block; padding: 13px 25px; background: #126a91; color: #ffffff !important; text-decoration: none; border-radius: 7px; font-size: 15px; font-weight: bold; }
ol { margin-top: 10px; margin-bottom: 25px; padding-left: 25px; }
ol li { margin-bottom: 9px; padding-left: 3px; font-size: 15px; line-height: 1.55; }
.footer { background: #f0f3f5; padding: 24px; text-align: center; color: #6b757b; font-size: 12px; line-height: 1.7; }
.footer-line { width: 45px; height: 3px; background: #f5c542; margin: 0 auto 15px; border-radius: 5px; }
@media screen and (max-width: 600px) {
  .email { padding: 10px 5px; }
  .container { border-radius: 10px; }
  .content { padding: 28px 22px; }
  .logo { width: 260px; }
  h2 { font-size: 21px; }
}
</style>
</head>
<body>
<div class="email">
<div class="container">
<div class="brand">
<img class="logo" src="${logoURL}" alt="JOTA-JOTI">
<div class="brand-title">Boulder Scout Group</div>
</div>
<div class="content">
<h2>Hello ${escapeHtml(account.parentName)},</h2>
<p>Thank you for submitting an Expression of Interest for <strong>${escapeHtml(account.childFirstName)} ${escapeHtml(account.childLastName)}</strong>.</p>
<div class="warning">
<strong>Important:</strong> This is only an <strong>Expression of Interest</strong>. It is not official registration or confirmation of participation. Further paperwork, permissions and consent may still be required.
</div>
<h3>Your child's account</h3>
<div class="login-box">
<div class="login-row"><span class="label">Child:</span><br>${escapeHtml(account.childFirstName)} ${escapeHtml(account.childLastName)}</div>
<div class="login-row"><span class="label">Username:</span><br><span class="value">${escapeHtml(account.username)}</span></div>
<div class="login-row"><span class="label">PIN:</span><br><span class="value">${escapeHtml(account.pin)}</span></div>
<div class="login-row"><span class="label">Password:</span><br><span class="value">${escapeHtml(account.password)}</span></div>
<div class="login-row"><span class="label">Participant ID:</span><br>${escapeHtml(account.participantID)}</div>
</div>
<p style="text-align:center">
<a class="button" href="${websiteURL}" target="_blank">Open JOTA-JOTI Website</a>
</p>
<h3>What happens next?</h3>
<ol>
<li>Your Expression of Interest has been received.</li>
<li>An account has been created for your child.</li>
<li>Further information will be provided later.</li>
<li>Any required paperwork and permissions must be completed.</li>
<li>Participation is subject to the required approvals and requirements.</li>
</ol>
<p>Please keep the username, PIN and password somewhere safe.</p>
</div>
<div class="footer">
<div class="footer-line"></div>
<strong>Boulder Scout Group</strong><br>JOTA-JOTI 2026<br><br>Unofficial JOTA-JOTI account system
</div>
</div>
</div>
</body>
</html>`;

  const plainTextBody =
    'JOTA-JOTI - Boulder Scout Group\n\n' +
    'Hello ' + account.parentName + ',\n\n' +
    'Thank you for submitting an Expression of Interest for ' + account.childFirstName + ' ' + account.childLastName + '.\n\n' +
    'YOUR CHILD ACCOUNT\n\n' +
    'Username: ' + account.username + '\n' +
    'PIN: ' + account.pin + '\n' +
    'Password: ' + account.password + '\n' +
    'Participant ID: ' + account.participantID + '\n\n' +
    'This is only an Expression of Interest. Further paperwork, permissions and consent may still be required.\n\n' +
    'Website: ' + websiteURL;

  MailApp.sendEmail({ to: account.parentEmail, subject: subject, body: plainTextBody, htmlBody: htmlBody });
}

function escapeHtml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

function testParentEmail() {
  const email = Session.getEffectiveUser().getEmail();
  if (!email) throw new Error('Could not determine your Google account email.');

  sendParentWelcomeEmail({
    parentName: 'Test Parent', parentEmail: email, childFirstName: 'Test', childLastName: 'Scout',
    ageYear: 'Year 10', participantID: 'JOTI-2026-000001', username: 'TestJOTA42',
    pin: '4827', password: 'Koala@42', allowedCategories: 'minecraft,games'
  });
}

/* ============================================================
   SYSTEM INITIALIZATION & TRIGGER SETUP
   ============================================================ */

function setupEOISystem() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();

  let usersSheet = spreadsheet.getSheetByName(CONFIG.USERS_SHEET);
  if (!usersSheet) usersSheet = spreadsheet.insertSheet(CONFIG.USERS_SHEET);

  if (usersSheet.getLastRow() === 0) {
    usersSheet.getRange(1, 1, 1, 17).setValues([[
      'ParticipantID', 'PIN', 'Name', 'Username', 'Email',
      'AllowedCategories', 'Password', 'ParentEmail', 'ParentName',
      'ScoutGroup', 'AgeYear', 'Status', 'EOIReceived',
      'AccountCreated', 'PaperworkStatus', 'EmailStatus', 'Notes'
    ]]);
    usersSheet.getRange(1, 1, 1, 17).setFontWeight('bold');
  }

  const triggers = ScriptApp.getProjectTriggers();
  triggers.forEach(function(trigger) {
    if (trigger.getHandlerFunction() === 'onFormSubmit') ScriptApp.deleteTrigger(trigger);
  });

  ScriptApp.newTrigger('onFormSubmit').forSpreadsheet(spreadsheet).onFormSubmit().create();

  ensureSheetExists(spreadsheet, CONFIG.CATEGORIES_SHEET);
  ensureSheetExists(spreadsheet, CONFIG.LINKS_SHEET);
  ensureSheetExists(spreadsheet, CONFIG.LOGOS_SHEET);
  ensureSheetExists(spreadsheet, CONFIG.BLOCKED_URLS_SHEET);
  ensureSheetExists(spreadsheet, CONFIG.BLOCKED_CATEGORIES_SHEET);
  ensureSheetExists(spreadsheet, CONFIG.SETTINGS_SHEET);

  createBackupTrigger();

  SpreadsheetApp.flush();
  Logger.log('EOI system setup completed successfully.');
  return 'EOI system setup completed successfully.';
}

function ensureSheetExists(spreadsheet, sheetName) {
  let sheet = spreadsheet.getSheetByName(sheetName);
  if (!sheet) sheet = spreadsheet.insertSheet(sheetName);
  return sheet;
}

function checkEOITrigger() {
  const triggers = ScriptApp.getProjectTriggers();
  const result = triggers.map(function(trigger) {
    return { function: trigger.getHandlerFunction(), type: String(trigger.getEventType()), source: String(trigger.getTriggerSource()) };
  });
  Logger.log(JSON.stringify(result, null, 2));
  return result;
}

/* ============================================================
   SYSTEM BACKUP
   ============================================================ */

function backupSpreadsheetToDrive() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const file = DriveApp.getFileById(spreadsheet.getId());
  const folder = getOrCreateBackupFolder();

  const timestamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || 'Etc/UTC', 'yyyy-MM-dd_HH-mm');
  const backupName = spreadsheet.getName() + ' — backup ' + timestamp;

  file.makeCopy(backupName, folder);
  pruneOldBackups(folder);

  Logger.log('Backup created: ' + backupName);
  return backupName;
}

function scheduledBackup() {
  try {
    backupSpreadsheetToDrive();
  } catch (error) {
    notifyAdminOfError('scheduledBackup', error);
  }
}

function getOrCreateBackupFolder() {
  const folders = DriveApp.getFoldersByName(CONFIG.BACKUP_FOLDER_NAME);
  if (folders.hasNext()) return folders.next();
  return DriveApp.createFolder(CONFIG.BACKUP_FOLDER_NAME);
}

function pruneOldBackups(folder) {
  const files = folder.getFiles();
  const list = [];
  while (files.hasNext()) {
    const f = files.next();
    list.push({ file: f, created: f.getDateCreated().getTime() });
  }
  list.sort(function(a, b) { return b.created - a.created; });
  for (let i = CONFIG.BACKUPS_TO_KEEP; i < list.length; i++) list[i].file.setTrashed(true);
}

function createBackupTrigger() {
  const triggers = ScriptApp.getProjectTriggers();
  triggers.forEach(function(trigger) {
    const fn = trigger.getHandlerFunction();
    if (fn === 'backupSpreadsheetToDrive' || fn === 'scheduledBackup') ScriptApp.deleteTrigger(trigger);
  });

  ScriptApp.newTrigger('scheduledBackup').timeBased().everyDays(1).atHour(3).create();
  Logger.log('Daily backup trigger created (runs around 3am).');
  return 'Daily backup trigger created (runs around 3am).';
}
