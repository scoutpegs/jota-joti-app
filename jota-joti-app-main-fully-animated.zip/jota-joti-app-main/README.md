# JOTA-JOTI Dashboard — Reactive / Loader / HTML Build

## Major repairs

### Loading and animation
- Restored the full-screen animated loading spinner for real logins.
- Added a second animated orbit indicator and animated loader background.
- Added a lightweight saved-session refresh spinner so fast reloads still provide visual feedback.
- Dashboard screens slide/fade into place instead of appearing abruptly.
- Category buttons react to pointer position, press, hover and focus.
- Access popups use a smoother bottom-sheet transition.
- Embedded pages open with a reactive full-screen slide/scale transition.
- Embedded content fades/scales in when its iframe is ready.

### Sheet HTML support
- Raw HTML in the sheet's URL field is automatically detected.
- HTML fragments are wrapped into a complete document with a mobile viewport.
- HTML is rendered through `srcdoc` in the embedded view.
- JavaScript in sheet HTML works.
- Forms, popups, downloads, fullscreen, clipboard actions and user-initiated top navigation are supported by the iframe sandbox configuration.
- A loading spinner remains visible while embedded content is loading.
- A 10-second slow-load message appears instead of leaving a blank page.
- Normal embeddable URLs still work.
- Normal URLs also get an `Open in browser` fallback button.

### Session / login
- Remembered accounts are restored immediately on reload.
- The login screen is not repeatedly shown while the remembered account is being refreshed.
- Current categories/links/logos are still fetched from the live backend.
- A temporary network failure does not automatically log the remembered account out.
- A genuine backend rejection clears the remembered session and requires a new PIN.

### Dashboard stability
- The countdown stops controlling the dashboard after the handoff.
- Repeated countdown updates cannot close an open category submenu.
- Dashboard grids are rebuilt only when their live data actually changes or a forced rebuild is requested.
- Category/submenu navigation is animated and reactive.

### PWA
- iPhone/iPad Add to Home Screen guidance remains.
- Android installation guidance remains.
- Manifest supports standalone mode and flexible orientation.
- Service-worker cache version is bumped so the new reactive build replaces older cached shells.
- Service-worker updates can activate without waiting for a full manual cache clear.

## Browser tests performed
- JavaScript syntax check with Node.js.
- Service-worker syntax check.
- Manifest JSON validation.
- Headless Chromium test with a remembered session.
- Category → submenu transition.
- Repeated timer updates while a submenu is open.
- Raw Sheet HTML → embedded page.
- Sheet HTML JavaScript button interaction.
- Embedded page loading transition.
- Embedded page Back transition.
- Spinner computed animation name verified as `spin`.
- No browser page errors in the test harness.

## 2026-09-07 Reactive animation polish

The supplied original animation system has been restored and extended across the dashboard.

### Animation improvements
- Original `fadeIn`, `slideUpIn`, `pulse`, and `spin` keyframes are retained.
- The main login/welcome spinner uses the supplied rotating `spin` animation.
- Embedded HTML has a dedicated rotating spinner and ready-state pulse.
- Password/access popups slide up with a spring-like overshoot and staggered content.
- Popup closing now animates smoothly instead of snapping away.
- PIN entry pulses on each change.
- Login errors shake visibly.
- Copy buttons animate when credentials are copied.
- Category cards react to pointer position and press state.
- Install buttons and install cards have smooth hover/press animations.
- Dashboard/submenu screens slide/fade in instead of appearing instantly.
- Reduced-motion preferences are still respected.

### Browser verification
- HTML/JavaScript syntax checks pass.
- Chromium test confirmed the main spinner uses `spin`.
- Chromium test confirmed submenu uses `pageEnter`.
- Chromium test confirmed password/access popup uses `passwordPopupIn`.
- Chromium test confirmed popup closing uses `passwordPopupOut`.
- Chromium test confirmed login errors use `loginShake`.
- Chromium test confirmed embedded HTML reaches `Ready`.
- Chromium test confirmed HTML from the sheet can execute its own JavaScript.
- Chromium test confirmed the embedded page can be closed cleanly after use.
